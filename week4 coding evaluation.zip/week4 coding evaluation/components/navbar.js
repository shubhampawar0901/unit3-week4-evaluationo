let navbar = () => {
	return `
    <h1>
    <a href="index.html">News App</a>
</h1>
<input
    type="text"
    id="search_input"
    placeholder="Search News"
/>
    `;
};

export { navbar };
